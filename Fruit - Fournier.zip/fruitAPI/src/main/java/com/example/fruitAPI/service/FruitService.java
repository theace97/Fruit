package com.example.fruitAPI.service;

import com.example.fruitAPI.model.Fruit;

import java.util.List;
import java.util.Optional;

public interface FruitService {
    void create(Fruit fruit);

    Optional<Fruit> getById(Long id);

    List<Fruit> get();

    void delete(Long id);

    Optional<Fruit> update(Fruit fruit);
}
