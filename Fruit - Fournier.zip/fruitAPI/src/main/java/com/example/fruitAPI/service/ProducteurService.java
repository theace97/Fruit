package com.example.fruitAPI.service;

import com.example.fruitAPI.model.Producteur;

import java.util.List;
import java.util.Optional;

public interface ProducteurService {
    void create(Producteur producteur);

    Optional<Producteur> getById(Long id);

    List<Producteur> get();

    void delete(Long id);

    Optional<Producteur> update(Producteur producteur);
}
