package com.example.fruitAPI.controler;

import com.example.fruitAPI.controler.dto.PaysRequestDto;
import com.example.fruitAPI.model.Pays;
import com.example.fruitAPI.service.PaysService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/pays")
public class PaysController {


    PaysService paysService;

    PaysController(PaysService paysService){
        this.paysService = paysService;
    }

    @GetMapping
    List<Pays> get(){
        return paysService.get();
    }

    @GetMapping("/{paysId}")
    Optional<Pays> getById(@PathVariable(name = "paysId") Long id){
        return paysService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody PaysRequestDto paysRequestDto){
        Pays paysToCreate = new Pays();

        paysToCreate.setName(paysRequestDto.getName());
        paysToCreate.setHemisphere(paysRequestDto.getHemisphere());
        paysToCreate.setContinent(paysRequestDto.getContinent());


        paysService.create(paysToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{paysId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long paysId){
        paysService.delete(paysId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }

}
