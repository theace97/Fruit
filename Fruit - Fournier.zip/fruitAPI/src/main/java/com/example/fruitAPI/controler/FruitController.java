package com.example.fruitAPI.controler;

import com.example.fruitAPI.controler.dto.FruitRequestDto;
import com.example.fruitAPI.model.Fruit;
import com.example.fruitAPI.service.FruitService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/fruits")
public class FruitController {
    FruitService fruitService;

    FruitController(FruitService fruitService){
        this.fruitService = fruitService;
    }

    @GetMapping
    List<Fruit> get(){
        return fruitService.get();
    }

    @GetMapping("/{fruitId}")
    Optional<Fruit> getById(@PathVariable(name = "fruitId") Long id){
        return fruitService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody FruitRequestDto fruitRequestDto){
        Fruit fruitToCreate = new Fruit();

        fruitToCreate.setCategory(fruitRequestDto.getCategory());
        fruitToCreate.setType(fruitRequestDto.getType());
        fruitToCreate.setName(fruitRequestDto.getName());
        fruitToCreate.setPrice(fruitRequestDto.getPrice());


        fruitService.create(fruitToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{fruitId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long fruitId){
        fruitService.delete(fruitId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }

}
