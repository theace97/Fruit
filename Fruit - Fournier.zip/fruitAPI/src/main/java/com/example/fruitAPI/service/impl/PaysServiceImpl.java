package com.example.fruitAPI.service.impl;


import com.example.fruitAPI.model.Pays;
import com.example.fruitAPI.repository.PaysRepository;
import com.example.fruitAPI.service.PaysService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class PaysServiceImpl implements PaysService {

    @Autowired
    PaysRepository paysRepository;

    @Override
    public void create(Pays pays) {
        paysRepository.save(pays);
    }

    @Override
    public Optional<Pays> getById(Long id) {
        return paysRepository.findById(id);
    }

    @Override
    public List<Pays> get() {
        return paysRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<Pays> paysToDelete = getById(id);
        paysRepository.delete(paysToDelete.get());
    }

    @Override
    public Optional<Pays> update(Pays pays) {
        paysRepository.save(pays);
        return Optional.empty();
    }
}
