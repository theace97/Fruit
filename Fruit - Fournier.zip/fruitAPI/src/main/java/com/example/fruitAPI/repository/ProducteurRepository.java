package com.example.fruitAPI.repository;

import com.example.fruitAPI.model.Producteur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface ProducteurRepository extends JpaRepository<Producteur, Long> {
}
