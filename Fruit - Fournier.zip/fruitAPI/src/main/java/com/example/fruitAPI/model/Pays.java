package com.example.fruitAPI.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "pays")
public class Pays {

    public Pays() {

    }

    public Pays(long id, String name, String hemisphere, String continent) {
        this.id = id;
        this.name = name;
        this.hemisphere = hemisphere;
        this.continent = continent;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String hemisphere;
    private String continent;

    @OneToMany(mappedBy = "pays")
    private List<Producteur> producteurs;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHemisphere() {
        return hemisphere;
    }

    public void setHemisphere(String hemisphere) {
        this.hemisphere = hemisphere;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }
}