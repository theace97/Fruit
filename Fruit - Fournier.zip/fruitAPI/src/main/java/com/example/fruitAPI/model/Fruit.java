package com.example.fruitAPI.model;

import jakarta.persistence.*;

@Entity
@Table(name = "fruits")
public class Fruit {

    public Fruit() {

    }

    public Fruit(long id, String category, String type, String name, float price) {
        this.id = id;
        this.category = category;
        this.type = type;
        this.name = name;
        this.price = price;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String category;
    private String type;
    private String name;
    private float price;
    @ManyToOne
    @JoinColumn(name = "producteur_id")
    private Producteur producteur;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategory() {

        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Producteur getProducteur() {

        return producteur;
    }

    public void setProducteur(Producteur producteur) {

        this.producteur = producteur;
    }
}
