package com.example.fruitAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class FruitApiApplication {

	@GetMapping
	public ResponseEntity<Map<String, Object>> hello(){
		Map<String, Object> responses = new HashMap<>();
		responses.put("Hello", "Welcome to my Fruit API");
		return ResponseEntity.ok(responses);
	}

	public static void main(String[] args) {
		SpringApplication.run(FruitApiApplication.class, args);
	}

}
