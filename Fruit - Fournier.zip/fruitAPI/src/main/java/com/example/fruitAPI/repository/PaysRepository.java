package com.example.fruitAPI.repository;

import com.example.fruitAPI.model.Pays;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PaysRepository extends JpaRepository<Pays, Long> {
}