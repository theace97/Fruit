package com.example.fruitAPI.controler;

import com.example.fruitAPI.controler.dto.ProducteurRequestDto;
import com.example.fruitAPI.model.Producteur;
import com.example.fruitAPI.service.ProducteurService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
@RestController
@RequestMapping("/api/producteur")
public class ProducteurController {
    ProducteurService producteurService;

    ProducteurController(ProducteurService producteurService){
        this.producteurService = producteurService;
    }

    @GetMapping
    List<Producteur> get(){
        return producteurService.get();
    }

    @GetMapping("/{producteurId}")
    Optional<Producteur> getById(@PathVariable(name = "producteurId") Long id){
        return producteurService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody ProducteurRequestDto producteurRequestDto){
        Producteur producteurToCreate = new Producteur();

        producteurToCreate.setLastname(producteurRequestDto.getLastname());
        producteurToCreate.setFirstname(producteurRequestDto.getFirstname());
        producteurToCreate.setDescription(producteurRequestDto.getDecription());
        producteurToCreate.setAddress(producteurRequestDto.getAddress());
        producteurToCreate.setCity(producteurRequestDto.getCity());

        producteurService.create(producteurToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{producteurId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long producteurId){
        producteurService.delete(producteurId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }



}
