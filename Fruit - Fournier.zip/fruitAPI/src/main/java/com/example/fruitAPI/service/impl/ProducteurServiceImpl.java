package com.example.fruitAPI.service.impl;

import com.example.fruitAPI.model.Producteur;
import com.example.fruitAPI.repository.ProducteurRepository;
import com.example.fruitAPI.service.ProducteurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProducteurServiceImpl implements ProducteurService {

    @Autowired
    ProducteurRepository producteurRepository;

    @Override
    public void create(Producteur producteur) {
        producteurRepository.save(producteur);
    }

    @Override
    public Optional<Producteur> getById(Long id) {
        return producteurRepository.findById(id);
    }

    @Override
    public List<Producteur> get() {
        return producteurRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<Producteur> producteurToDelete = getById(id);
        producteurRepository.delete(producteurToDelete.get());
    }

    @Override
    public Optional<Producteur> update(Producteur producteur) {
        producteurRepository.save(producteur);
        return Optional.empty();
    }
    
    
    
}
