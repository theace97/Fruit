package com.example.fruitAPI.service.impl;

import com.example.fruitAPI.model.Fruit;
import com.example.fruitAPI.repository.FruitRepository;
import com.example.fruitAPI.service.FruitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class FruitServiceImpl implements FruitService {

    @Autowired
    FruitRepository fruitRepository;

    @Override
    public void create(Fruit fruit) {
        fruitRepository.save(fruit);
    }

    @Override
    public Optional<Fruit> getById(Long id) {
        return fruitRepository.findById(id);
    }

    @Override
    public List<Fruit> get() {
        return fruitRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<Fruit> fruitToDelete = getById(id);
        fruitRepository.delete(fruitToDelete.get());
    }

    @Override
    public Optional<Fruit> update(Fruit fruit) {
        fruitRepository.save(fruit);
        return Optional.empty();
    }
}
