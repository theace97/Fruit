package com.example.fruitAPI.service;

import com.example.fruitAPI.model.Pays;

import java.util.List;
import java.util.Optional;

public interface PaysService {
    void create(Pays pays);

    Optional<Pays> getById(Long id);

    List<Pays> get();

    void delete(Long id);

    Optional<Pays> update(Pays pays);
}
