INSERT INTO pays (id, name, hemisphere, continent)
VALUES (10, 'France', 'Nord', 'Europe');

INSERT INTO pays (id, name, hemisphere, continent)
VALUES (11, 'Afrique du Sud', 'Sud', 'Afrique');


INSERT INTO producteurs (id, lastname, firstname,description, address, city, paysId)
VALUES (1, 'Germian', 'Roseline', 'bio', 'rue du charter', 'Parlaland',10);

INSERT INTO producteurs (id, lastname, firstname,description, address, city,paysId)
VALUES (2, 'Merlin', 'Beber', 'pesticide', 'rue de la grange', 'PerduLand',11);

INSERT INTO producteurs (id, lastname, firstname,description, address, city,paysId)
VALUES (3, 'Berlu', 'Jojo', 'Bio', 'rue du moulin', 'Campagnoland',10);


INSERT INTO fruits (id, category, type, name, price, producteurId)
VALUES (100, 'fragaria', 'rosacees', 'fraise', 10, 1);

INSERT INTO fruits (id, category, type, name, price, producteurId)
VALUES (101, 'pommier', 'gala' , 'pomme', 15, 2);

INSERT INTO fruits (id, category, type, name, price, producteurId)
VALUES (102, 'prune', 'prunille', 'Reine claude', 8, 3);


